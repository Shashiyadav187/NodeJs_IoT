var express = require('express');
var app = require('../app');
var rest = require('../rest');
var router = express.Router();
var expressValidator = require('express-validator');

//logging
router.use(function(req, res, next) {
  console.log('%s %s %s', req.method, req.url, req.path);
  next();
});
router.use(function timeLog(req, res, next) {
  console.log('Time: ', Date.now())
  next()
});

/* GET home page. */
router.get('/', function(req, res, next) {
  // find everything
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('/sw.js').then(function(
        registration) {
        // Registration was successful
        console.log(
          'ServiceWorker registration successful with scope: ',
          registration.scope);
      }, function(err) {
        // registration failed :(
        console.log('ServiceWorker registration failed: ', err);
      });
    });
  }
  res.send(new Buffer('whoop'));
  res.status(404).send('Sorry, we cannot find that!');
  res.status(500).send({
    error: 'something blew up'
  });
  res.render('index', {
    layout: 'indexLayout',
    title: 'Home Automation'
  });
  req.session.errors = null;
  //res.render('index.html');
});

//App route for Login page
router.route('/login')
  .get(function(req, res, next) {
    res.render('login', {
      layout: 'loginLayout',
      title: 'Login',
      success: req.session.success,
      errors: req.session.errors
    });
    next();
  })

.post(function(req, res) {
    // var username = req.body.username;
    // var password = req.body.password;
    session = req.session;
    req.check('username', 'Invalid username').notEmpty();
    console.log('Username check done');
    //req.check('email', 'Invalid email address').isEmail();
    req.check('password', 'Password is invalid').isLength({
      min: 4
    }).matches(/\d/);
    console.log('Pass check done');
    var errors = req.validationErrors();
    if (errors) {
      req.session.errors = errors;
      req.session.success = false;
    } else {
      req.session.success = true;
    }
    let username = req.body.username;
    let password = req.body.password;
    session.uniqueId = username;
    if (username == 'admin' && password == 'admin') {
      console.log('Check for admin');
      console.log("Username = " + username + ", password is " + password);
      console.log("Login form submitted");
      console.log('Session ID is ' + session.uniqueId);
      res.redirect('/redirect');

    } else {
      console.log('Session is not admin');
      res.send('Hey ' + session.uniqueId +
        ' You are not Authorized  <a href = "/logout" > Logout </a>'
      );
    }
    //if(req.body.user == 'admin' && req.body.password == 'admin'){}
  })
  .put(function(req, res) {

    var username = req.body.username;
    var email = req.body.email;
    var new_password = req.body.password;
    expressSession = req.session;
    if (session.uniqueId) {
      res.redirect('/redirect')
    }
    session.uniqueId = req.body.username;
    console.log("User name = " + username + ",Email is" + email +
      ", New password is " +
      new_password);
    res.send('Updated the login password');
    next()
    console.log("password updated");
    res.redirect('/login');
  });

//App route for signup page
router.route('/signup')
  .get(function(req, res) {
    res.render('signup', {
      layout: 'signupLayout',
      title: 'Signup',
      success: req.session.success,
      errors: req.session.errors
    });
    req.session.errors = null;
  })
  .post(function(req, res) {
    var username = req.body.username;
    var email = req.body.email;
    var password = req.body.password;
    req.check('username', 'Invalid username').notEmpty(),
      req.check('email', 'Invalid email address')
      // Every validator method in the validator lib is available as a
      // method in the check() APIs.
      // You can customize per validator messages with .withMessage()
      .isEmail().withMessage('must be an email')

    // Every sanitizer method in the validator lib is available as well!
    .trim()
      .normalizeEmail();

    req.check('password',
      'passwords must be at least 4 chars long and contain one number').isLength({
      min: 4
    }).equals(req.body.confirmPassword);
    //Run the validators
    var errors = req.validationErrors();
    if (errors) {
      req.session.errors = errors;
      req.session.success = false;
    } else {
      req.session.success = true;
      res.redirect('/signup')
    }
    console.log("Username = " + username + ",Email is" + email +
      ", password is " + password);
    console.log("Signup Successful");
    res.send('Hey ' + req.body.username +
      ' Your Signup is Successful. Click ====>   <a href = "/" > to Login </a>'
    );
    //res.render('ledcontrol.html');

  });

//Session logout
router.get('/logout', function(req, res) {
  req.session.destroy();
  console.log('session ID has been destroyed');
  res.redirect('/');
});

//Session redirect
router.get('/redirect', function(req, res) {
  session = req.session;
  if (session.uniqueId == 'admin') {
    console.log(session.uniqueId);
    res.redirect('/admin');
  } else {
    res.send('Hey ' + session.uniqueId +
      ' You are not Authorized  <a href = "/logout" >Logout </a>');
    req.session.destroy(function(error) {
      //call back
      console.log(error);
    });
    res.redirect('/logout');
  }
});

router.get('/admin', function(req, res) {
  session = req.session;
  if (session.uniqueId != 'admin') {
    res.send(
      'Unauthorized access  <a href = "/logout">Back to login page</a>');
    res.redirect('/logout');
  } else {
    console.log('Logged in As Admin');
    res.redirect('/ledcontrol');
  }

  //res.end(JSON.stringify(req.params));
});

router.get('/ledcontrol', function(req, res) {
  expressSession = req.session;
  if (session.uniqueId != 'admin') {
    res.send(
      'Unauthorized access  <a href = "/">Back to Home page</a>');
    res.redirect('/logout');
  }
  console.log('Logged in As Admin to Ledcontrol');
  res.render('ledcontrol', {
    layout: 'LedcontrolLayout',
    title: 'Ledcontrol'
  });
});

//App route for publishing RGB data
router.post('/user/rgbdata', function(req, res) {
  console.log(req.body); // your JSON
  res.send(req.body); // echo the result back
  console.log("form submitted");

});

//for API call
router.get('/api', function(req, res) {
  //res.send('Welcome to my API');
  var url =
    'http://samples.openweathermap.org/data/2.5/forecast?id=524901&appid=b1b15e88fa797225412429c1c50c122a1';
  request.get(url, (error, response, body) => {
    let json = JSON.parse(body);
    console.log("Got a response: ", json);
    res.end(JSON.stringify(url));
    /* http.get(url, function(res){
        var body = '';

        res.on('data', function(chunk){
            body += chunk;
        });

        res.on('end', function(){
            var APIRes = JSON.parse(body);
            console.log("Got a response: ", APIRes.json);
        });
    }).on('error', function(e){
          console.log("Got an error: ", e);
    }); */
  });
});

module.exports = () => 'Hello, world!'
module.exports = router;
