// db.js
var mongoose = require('mongoose');
mongoose.connect(
  'mongodb://lucky:lucky123@ds237475.mlab.com:37475/restapi_test');
var mongoDB = process.env.MONGODB_URI ||
  'mongodb://lucky:lucky123@ds237475.mlab.com:37475/restapi_test';
//mongoose = mongojs('mongodb://luckyhegde:Laxmish6@ds237475.mlab.com:37475/', ["restapi_a1"], {authMechanism: 'ScramSHA1'});
//mongoose.connect('mongodb://${luckyhegde}:${Laxmish6}@${ds237475.mlab.com:37475/}/${restapi_test}?authMechanism=MONGODB-CR')
//mongoose.connect('mongodb://${luckyhegde}:${Laxmish6}@${ds237475.mlab.com:37475/}/${restapi_test}?authMechanism=SCRAM-SHA-1')
// var MongoClient = require('mongodb').MongoClient;
//
// var uri = "mongodb://user123:p455w0rd@gettingstarted-shard-00-00-hyjsm.mongodb.net:27017,gettingstarted-shard-00-01-hyjsm.mongodb.net:27017,gettingstarted-shard-00-02-hyjsm.mongodb.net:27017/test?ssl=true&replicaSet=GettingStarted-shard-0&authSource=admin";
// MongoClient.connect(uri, function(err, db) {
//   // Paste the following examples here
//
//   db.close();
// });
