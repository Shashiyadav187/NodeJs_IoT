function checkO(value)                                         //function for Dropdown value check 
	{	alert("The input value has changed. The new value is: " + value); //alert for Dropdown value change
			var rgb = document.getElementById('ctverec');					//<!-- Div for RGB box--></!-->
			var r = document.getElementById('RGB');					//<!-- Div for RGB--></!-->
			var w = document.getElementById('dvR');					//<!-- Div for analog slider --></!-->
			var x = document.getElementById('dvA');					//<!-- Div for analog view check --></!-->
			var y = document.getElementById('dvN');					//<!-- Div for Digital view check  --></!-->
			var z = document.getElementById('sliderAmountR');		//<!-- Div for Analog slider value view check  --></!-->
	
		switch(value) 
		{
		case 'Analog' :
		{
			if (x.style.display === 'none') {
			rgb.style.display = 'none';
			r.style.display = 'none';
			x.style.display = 'block';
			y.style.display = 'none';
			z.style.display = 'block';
			
			
			} 
			else {x.style.display = 'none';
			}
		}
			break;
		case 'Digital':
		{
			if (y.style.display === 'none') {
			rgb.style.display = 'none';
			r.style.display = 'none';
			y.style.display = 'block';
			x.style.display = 'none';
			z.style.display = 'none';
			w.style.display = 'none';
			} 
			else {y.style.display = 'none';}
		}
		break;
		
		case'RGB' :
		{
			if (rgb.style.display === 'none'&&
			r.style.display === 'none') {
			
			rgb.style.display = 'block';
			r.style.display = 'block';
			y.style.display = 'none';
			x.style.display = 'none';
			z.style.display = 'none';
			w.style.display = 'none';
			} 
			else {rgb.style.display = 'none';
			r.style.display = 'none';}
		}
		break;
		
		default:{
			r.style.display = 'none';
			rgb.style.display = 'none';
			r.style.display = 'none';
			w.style.display = 'none';
			y.style.display = 'none';
			x.style.display = 'none';
			z.style.display = 'none';
			}
			
		}
	}
	//function for checkbox hide unhide  slider
	function Showcheck()					
	{	var dvR = document.getElementById("dvR");
        dvR.style.display = chkR.checked ? "block" : "none";
    }
//function for Slider Value updating
	function changeR(slideAmountR){		 
        var sliderDiv = document.getElementById("sliderAmountR");
        sliderDiv.innerHTML = "Analog Value is " + slideAmountR;
         var xhr = new XMLHttpRequest();
var url = "/user/rgbdata";
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-type", "application/json");
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var json = JSON.parse(xhr.responseText);
       console.log(json.slideAmountR);
    }
};
  var data = JSON.stringify({"Analogval": slideAmountR});    
xhr.send(data);
    }
function light()
{   var Sw1 = document.getElementById('LED1').value ;
 var Sw2 = document.getElementById('LED2').value;
 var Sw3 = document.getElementById('LED3').value;
 var Sw4 = document.getElementById('LED4').value;
    
    var url = "/user/rgbdata";
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-type", "application/json");
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var json = JSON.parse(xhr.responseText);
       console.log(json.Sw1+","+json.Sw2+","+json.Sw3+","+json.Sw4);
    }
};
  var data = JSON.stringify({"Digival1": Sw1 ,"Digival2": Sw2,"Digival1": Sw3 ,"Digival2": Sw4});    
xhr.send(data);
}
//Test function for Slider Value updating 
	function myFunctionV(val)         
	{
    alert("The input value has changed. The new value is: " + val);
	}
//Test function for hiding Div
function myFunction() { 		
    var x = document.getElementById('myDIV');
    if (x.style.display === 'block') {
        x.style.display = 'none';
    } else {
        x.style.display = 'block';
    }
}

//function for RGB value change
function pick (value) {				

 var red = document.getElementById("red").value;
  var green = document.getElementById("green").value;
  var blue = document.getElementById("blue").value;
 document.getElementById('ctverec').style.background = 'rgb('+ red + ',' + green + ',' + blue +')';
 document.getElementById("valRed").innerHTML = "Red Value is " + red;
 document.getElementById("valGreen").innerHTML = "Green Value is " + green;
 document.getElementById("valBlue").innerHTML = "Blue Value is " + blue;

}
//Function for posting RGBdata to MCU
function sendRGB(){
    var red = document.getElementById("red").value;
  var green = document.getElementById("green").value;
  var blue = document.getElementById("blue").value;
    var RGBval = 'rgb('+ red + ',' + green + ',' + blue +')';
    alert("The RGB value is: " + RGBval);
 var xhr = new XMLHttpRequest();
var url = "/user/rgbdata";
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-type", "application/json");
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var json = JSON.parse(xhr.responseText);
        //console.log(json.email + ", " + json.password);
       console.log(json.RGBval);
    }
};
//var data = JSON.stringify({"email": "hey@mail.com", "password": "101010"});
  var data = JSON.stringify({"RGBval": RGBval});    
xhr.send(data);   
    
/*receiving data in JSON format using GET method
var xhr = new XMLHttpRequest();
var url = "url?data=" + encodeURIComponent(JSON.stringify({"RGBval": RGBval}));
xhr.open("GET", url, true);
xhr.setRequestHeader("Content-type", "application/json");
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        var json = JSON.parse(xhr.responseText);
        console.log(json.RGBval);
    }
};
xhr.send();*/
    
}