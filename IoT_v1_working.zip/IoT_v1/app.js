var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var hbs = require('express-handlebars');
var expressValidator = require('express-validator');
var session = require('express-session');
var url = require('url');
var fs = require('fs');
var adr = 'http://localhost:3000/';
var q = url.parse(adr, true);
var app = express();
//var os = require( 'os' );
var ip = require("ip");
//var routes = require('./routes');
var routes = require('./routes/index');
var users = require('./user/User.js');
//var catalog = require('./routes/catalog'); //Import routes for "catalog" area of site
var compression = require('compression');
var helmet = require('helmet');
app.use(helmet());
app.use(compression()); //Compress all routes
app.use(expressValidator());


//console.dir ( ip.address() );
//var networkInterfaces = os.networkInterfaces( );
// console.log( networkInterfaces );
// Define the port to run on
var loggerf = function(req, res, next) {
  console.log('logging.......');
  console.log('Requester IP :' + ip.address());
  console.log(q.host); //returns 'localhost:8080'
  console.log(q.pathname); //returns '/default.htm'
  console.log(q.search);
  next();
}
var options = {
  dotfiles: 'ignore',
  etag: false,
  extensions: ['hbs', 'htm', 'html'],
  index: false,
  maxAge: '1d',
  redirect: false,
  setHeaders: function(res, path, stat) {
    res.set('x-timestamp', Date.now())
  }
}

// simple logger for this router's requests
app.use(loggerf);

//view Engine
//app.set('view engine','ejs');
//app.set('html',path.join(__dirname,'views'));
// app.set('view engine', 'html');
// app.set('html', __dirname + '/public');
// view engine setup
// app.set('view engine', 'html');
// app.set('html', __dirname + '/public');
// view engine setup
app.engine('hbs', hbs({
  extname: 'hbs',
  //defaultLayout: 'layout',
  layoutsDir: __dirname + '/views/layouts/'
}));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');


// var hbs = require('hbs');
// hbs.registerPartials(__dirname + '/views/partials' [, callback]);
// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
app.use(expressValidator());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'lucky',
  saveUninitialized: false,
  resave: false,
  duration: 24 * 60 * 60 * 1000, // how long the session will stay valid in ms
  activeDuration: 1000 * 60 * 5 // if expiresIn < activeDuration, the session will be extended by activeDuration milliseconds
}));
// GET method route
// var router = express.Router([options]);
// app.use(express.static('public', options))
// app.use('/users', users);
//app.use('/catalog', catalog); // Add catalog routes to middleware chain. */
app.use('/', routes);
// middleware that is specific to this router
// all requests to this router will first hit this middleware
// router.use(function(req, res, next) {
//   console.log('%s %s %s', req.method, req.url, req.path);
//   next();
// });
// router.use(function timeLog(req, res, next) {
//   console.log('Time: ', Date.now())
//   next()
// });



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
