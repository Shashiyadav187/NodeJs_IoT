// app.js

var express = require('express');
var rest = express();
var db = require('./db');

// ADD THESE TWO LINES
var UserController = require('./user/UserController');
rest.use('/users', UserController);

module.exports = rest;
