// using the require function/module

var response = require('./methods.js');
console.log(response);
