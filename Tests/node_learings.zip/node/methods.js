var methods = {};

methods.updateServer = function(){
console.log('Important functions');
};

methods.updateNetwork = function(){
console.log('Important network alerts');
};

methods.updateMsgs = function(){
console.log('Important messages');
};

exports.data = methods;
