//Rendering static files in Express

var express = require('express');
var app = express();

app.use('/css',express.static(__dirname + '/css')); //to access the /csss folder by css tag

app.get('/statfile',function (req,res) {
  res.send('Hi From Express,here is your static file');
});
app.listen(3000,function(){
  console.log('Server started at 3000');
});
