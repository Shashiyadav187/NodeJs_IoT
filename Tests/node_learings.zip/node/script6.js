//Example for filesystem

var fs = require('fs');
console.log('Starting Reading Files,  3...2...1... :)');
/*
fs.readFile('./files/file.txt','utf8',function (error,data) {
  console.log(data);
});
//file reding will be done async...to avoid this use readFileSync
*/
var data = fs.readFileSync('./files/file.txt','utf8',function (error,data) {
});
console.log(data);
console.log('Executed after Reading,  might be :)');
