//Events & eventEmitter

var events = require('events');
var eventEmitter = new events.EventEmitter();

eventEmitter.on('myCustomEvent',function(){
  console.log('Event fired');
  console.log('Counting 0 to 1000');
  for(i=0;i<1001;i++)
  {console.log(i);}
});

setTimeout(function(){
  eventEmitter.emit('myCustomEvent');
},2000)

//document.querySelector('yourTag').onclick = function(...........);
