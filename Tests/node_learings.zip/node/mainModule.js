module.exports = {
currentUrl : 'https://www.google.com'
}
 
