//for File I/O operations

var fs = require('fs');
console.log('Starting writing into Files,  3...2...1... :)');
/*
fs.readFile('./files/file.txt','utf8',function (error,data) {
  console.log(data);
});
//file reding will be done async...to avoid this use readFileSync
*/
var data = fs.writeFileSync('./files/file2.txt','Hi, writing into the file','utf8',function (error) {
  if (error) throw error;
});
console.log('File writing done,  might be :)');
//console.log(data);
console.log('Executed after writing into File,  might be :)');
