//Use of http module
/*
var server = require('http');

server.createServer(engine).listen(3000)

function engine(req,res)
{
  res.writeHead(200,{'Content-Type': 'text/plain'});
  res.end('Hi from the server')
};
*/
var http = require('http');

var server = http.createServer(engine);
server.listen(3000,function() {
  console.log('Server got a hit');

});
function engine(req,res)
{
  res.writeHead(200,{'Content-Type': 'text/plain'});
  res.end('Hi from the server, Request Page from '+ req.url);
  //console.log(res);
};
