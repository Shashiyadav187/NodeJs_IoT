var res = require('./methods2');

console.log(res);
