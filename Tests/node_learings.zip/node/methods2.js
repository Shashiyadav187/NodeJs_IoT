var methods = module.export = {};

module.exports = {
  sumNumbers : function () {},
  prodNumbers :function () {},
  modNumbers : function () {}
}

methods.sumNumbers = function(a,b){
  output = a+b;
  return output;
}

methods.prodNumbers = function(a,b){
  output = a*b;
  return output;
}

methods.modNumbers = function(a,b){
  output = a/b;
  return output;
}

module.exports.data = methods;
