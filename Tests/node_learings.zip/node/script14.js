//Rendering Routing in Express
var express = require('express');
var path = require('path');
var app = express();
var router =express.Router();

app.use('/', router);

router.get('/:index',function(req,res) {
  res.end(JSON.stringify(req.params));
  //res.end('Routing to index');
});

router.get('/app',function(req,res) {
  res.end('Routing to app');
});

router.post('/', function(req, res) {
res.end(JSON.stringify(req.params));
});
//////////////////middle parser///////////////
/*
  res.end(JSON.stringify(req.query))
  res.sendFile('index.html', {
    root: path.join(__dirname, './files')
  });

});  */
// app.get(/^(.+)$/,function (req,res) {
//   console.log(path.join(__dirname,'./files/',req.params[0],'.html'));
//   try {
//     if(fs.statSync(path.join(__dirname,'./files/',req.params[0]+'.html')).isFile()){
//     res.sendFile(req.params[0]+'.html',{root:path.join(__dirname,'./files')});}
//   } catch (e) {
//   res.sendFile('error.html',{root:path.join(__dirname,'./files')});
// }
// });

app.listen(3000, function() {
  console.log('Server started at 3000');
});
