var moduleX = require('./mainModule');
console.log('Current Url' + moduleX.currentUrl)
