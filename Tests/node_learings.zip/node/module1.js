var moduleX = require('./mainModule');
moduleX.currentUrl = 'http://yahoo.com'
console.log('Current Url' + moduleX.currentUrl)
