//Rendering html files in Express

var express = require('express');
var path = require('path');
var fs = require('fs')
var app = express();

//app.use('/css',express.static(__dirname + '/css')); //to access the /csss folder by css tag

app.get('/',function (req,res) {
  res.sendFile('index.html',{root:path.join(__dirname,'./files')});
});

app.get(/^(.+)$/,function (req,res) {
  console.log(path.join(__dirname,'./files/',req.params[0],'.html'));
  try {
    if(fs.statSync(path.join(__dirname,'./files/',req.params[0]+'.html')).isFile()){
    res.sendFile(req.params[0]+'.html',{root:path.join(__dirname,'./files')});}
  } catch (e) {
  res.sendFile('error.html',{root:path.join(__dirname,'./files')});
}
});

app.listen(3000,function(){
  console.log('Server started at 3000');
});
