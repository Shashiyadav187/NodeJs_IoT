var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');

var expressvalidator = require('express-validator');
var app = express();
// Define the port to run on
app.set('port', 3000);
var logger = function(req,res,next){
    console.log('logging.......');
    next();
}

app.use(logger);

//view Engine
//app.set('view engine','ejs');
//app.set('html',path.join(__dirname,'views'));
app.set('view engine', 'html'); app.set('html', __dirname + '/public');

//bodyparser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

//Set path for static
app.use(express.static(path.join(__dirname, 'public')));

 
// GET method route
app.get('/', function (req, res) {
    // find everything
    res.render('index.html');
});
app.post('/user/rgbdata', function (req, res) {
    console.log(req.body);      // your JSON
   res.send(req.body);    // echo the result back
   /*var errors = req.validationErrors(); //req.getValidationResult()
    if (errors){
        console.log("Error found data not sent");
    }
    else{
        res.render('index.html');
    console.log("form submitted");
    }*/
   
});
// Listen for requests
var server = app.listen(app.get('port'), function() {var port = server.address().port;
  console.log('Running server at Port ' + port);});