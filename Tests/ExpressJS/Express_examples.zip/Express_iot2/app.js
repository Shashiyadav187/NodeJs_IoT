var express = require('express');
var bodyParser = require('body-parser');
//var passport = require('passport');
var path = require('path');
var url = require('url');
var fs = require('fs');
var adr = 'http://localhost:3000/';
var q = url.parse(adr, true);
var expressvalidator = require('express-validator');
var app = express();
var flash    = require('connect-flash');
var morgan       = require('morgan');
var cookieParser = require('cookie-parser');
var session      = require('express-session');
//var os = require( 'os' );
var ip = require("ip");
//console.dir ( ip.address() );
//var networkInterfaces = os.networkInterfaces( );
// console.log( networkInterfaces );
// Define the port to run on
app.set('port', 3000);
// require('./config/passport')(passport); // pass passport for configuration
var logger = function(req,res,next){
    console.log('logging.......');
   console.log('Requester IP :' + ip.address() );
    console.log(q.host); //returns 'localhost:8080'
console.log(q.pathname); //returns '/default.htm'
console.log(q.search);
    next();
}
// required for passport
app.use(session({ secret: 'itsluckyhegde' })); // session secret
app.use(flash()); // use connect-flash for flash messages stored in session
require('./config/passport')(passport);
app.use(passport.initialize())  
app.use(passport.session()); // persistent login sessions


app.use(logger);
//view Engine
//app.set('view engine','ejs');
//app.set('html',path.join(__dirname,'views'));
app.set('view engine', 'html'); app.set('html', __dirname + '/public');

//bodyparser middleware
app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser()); // get information from html forms
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

//Set path for static
app.use(express.static(path.join(__dirname, 'public')));

// GET method route
app.get('/', function (req, res) {
    // find everything
    if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js').then(function(registration) {
      // Registration was successful
      console.log('ServiceWorker registration successful with scope: ', registration.scope);
    }, function(err) {
      // registration failed :(
      console.log('ServiceWorker registration failed: ', err);
    });
  });
}
    res.render('index.html');
});
app.get('/login',function(req,res){
  res.render('login.html');
});
 // process the login form
    app.post('/login', passport.authenticate('local-login', {
        successRedirect : '/ledcontrol', // redirect to the secure profile section
        failureRedirect : '/login', // redirect back to the signup page if there is an error
        failureFlash : true // allow flash messages
    }));
app.get('/signup',function(req,res){
  res.render('signup.html');
});
app.get('/ledcontrol',function(req,res){
  res.render('ledcontrol.html');
});
app.post('/login',function(req,res){
  var user_name=req.body.email;
  var password=req.body.password;
  console.log("User name = "+user_name+", password is "+password);
    res.end();
});
app.post('/signup',function(req,res){
  var user_name=req.body.email;
  var password=req.body.password;
  console.log("User name = "+user_name+", password is "+password);
  res.render('ledcontrol.html');
    res.end();
});

app.post('/user/rgbdata', function (req, res) {
          console.log(req.body);      // your JSON
   res.send(req.body);    // echo the result back
    console.log("form submitted");
    
});
// Listen for requests
var server = app.listen(app.get('port'), function() {var port = server.address().port;
  console.log('Running server at Port ' + port);});