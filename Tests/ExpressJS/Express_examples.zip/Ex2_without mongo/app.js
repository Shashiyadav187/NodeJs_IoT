var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');

var expressvalidator = require('express-validator');

var app = express();
//app.use(expressValidator(middlewareOptions));
// Define the port to run on
app.set('port', 3000);
/*var logger = function(req,res,next){
    console.log('logging.......');
    next();
}

app.use(logger);*/
//view Engine
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));

//bodyparser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

//Set path for static
//app.use(express.static(path.join(__dirname, 'public')));

 //global vars
app.use(function(req,res,next)
        {res.locals.errors = null;
          next();
        });

//Express validator middleware
app.use(expressvalidator({
        errorFormatter : function(param,msg,value){
    var namespace =param.split('.'),
        root = namespace.shift(),
        formParam = root;
            
    while(namespace.length){
        formParam += '['+ namespace.shift() + ']'}
    return{
        param : formParam,
        msg : msg,
        value : value
    };
}
        
        }));

var users = [{ id:1,fname : "jeff",lname :'jsadh',email:'jeffasd@gmail.com' },{ id:2, fname : "jerry",lname :'asjh',email:'jerryAsf@gmail.com'},{id:3, fname : "mong",lname :'nks',email:'mongnks@gmail.com'}]

// GET method route
app.get('/', function (req, res) {
    // find everything
db.users.find(function (err, docs) {
    console.log(docs);
    res.render('index',{title:'Customers', users: docs });
	// docs is an array of all the documents in mycollection
})

// find everything, but sort by name
db.mycollection.find().sort({name: 1}, function (err, docs) {
	// docs is now a sorted array
})
  res.render('index',{title:'Customers', users: users});
});
app.post('/user/add', function (req, res) {
    req.checkBody('fname','First name is required').notEmpty();
    req.checkBody('lname','Last name is required').notEmpty();
    req.checkBody('email','email is required').notEmpty();
   var errors = req.validationErrors(); //req.getValidationResult()
    if (errors){
         res.render('index',{title:'Customers', users: users,errors : errors});
        console.log("Error found form not submitted");
    }
    else{
         var newuser = { fname: req.body.fname,lname: req.body.lname,email: req.body.email}
    console.log(newuser);
    console.log("form submitted");
    }
   
});
// Listen for requests
var server = app.listen(app.get('port'), function() {var port = server.address().port;
  console.log('Running server at Port ' + port);});