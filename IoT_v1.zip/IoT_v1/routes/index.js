var express = require('express');
var app = require('../app');
var rest = require('../rest');
var router = express.Router();
const {
  check, validationResult
} = require('express-validator/check');
const {
  matchedData, sanitize
} = require('express-validator/filter');
// GET method route
// var router = express.Router([options]);
// app.use(express.static('public', options))
//var index = require('./routes/index');
//var users = require('./users');
//var catalog = require('./routes/catalog');
//app.use('/', index);
// app.use('/users', users);
//app.use('/catalog', catalog); // Add catalog routes to middleware chain. */
/* GET home page. */
router.get('/', function(req, res) {
  // find everything
  req.session.errors = null;
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('/sw.js').then(function(
        registration) {
        // Registration was successful
        console.log(
          'ServiceWorker registration successful with scope: ',
          registration.scope);
      }, function(err) {
        // registration failed :(
        console.log('ServiceWorker registration failed: ', err);
      });
    });
  }
  res.send(new Buffer('whoop'));
  res.status(404).send('Sorry, we cannot find that!');
  res.status(500).send({
    error: 'something blew up'
  });
  res.render('index', {
    layout: 'indexLayout.hbs',
    title: 'Home Automation',
    success: req.session.success,
    errors: req.session.errors
  });
  //res.render('index.html');
});

//App route for Login page
router.route('/login')
  .get(function(req, res) {
    res.render('login', {
      layout: 'layouts/loginLayout.hbs',
      title: 'Login',
      success: req.session.success,
      errors: req.session.errors
    });
  })

.post(function(req, res) {
    var username = req.body.username;
    var password = req.body.password;
    session = req.session;
    check('username', 'Invalid username').isNull();
    //req.check('email', 'Invalid email address').isEmail();
    check('password', 'Password is invalid').isLength({
      min: 4
    }).matches(/\d/);
    var errors = req.validationErrors();
    if (errors) {
      req.session.errors = errors;
      req.session.success = false;
    } else {
      req.session.success = true;
    }
    if (session.uniqueId) {
      session.uniqueId = username;
      console.log("Username = " + username + ", password is " + password);
      console.log("Login form submitted");
      res.redirect('/redirect');
    } else {
      res.redirect('/')
    }
    //if(req.body.user == 'admin' && req.body.password == 'admin'){}
  })
  .put(function(req, res) {

    var username = req.body.username;
    var email = req.body.email;
    var new_password = req.body.password;
    session = req.session;
    if (session.uniqueId) {
      res.redirect('/redirect')
    }
    session.uniqueId = req.body.username;
    console.log("User name = " + user_name + ",Email is" + email +
      ", New password is " +
      new_password);
    res.send('Updated the login password');
    next()
    console.log("password updated");
    res.redirect('/login');
  });

//App route for signup page
router.route('/signup')
  .get(function(req, res) {
    res.render('signup', {
      layout: 'layouts/signupLayout.hbs',
      title: 'Signup',
      success: req.session.success,
      errors: req.session.errors
    });
  })
  .post(function(req, res) {
    var username = req.body.username;
    var email = req.body.email;
    var password = req.body.password;
    check('username', 'Invalid username').isNull(),
      check('email', 'Invalid email address')
      // Every validator method in the validator lib is available as a
      // method in the check() APIs.
      // You can customize per validator messages with .withMessage()
      .isEmail().withMessage('must be an email')

    // Every sanitizer method in the validator lib is available as well!
    .trim()
      .normalizeEmail()

    // ...or throw your own errors using validators created with .custom()
    .custom(value => {
        return findUserByEmail(value).then(user => {
          throw new Error('this email is already in use');
        })
      }),
      check('password',
        'passwords must be at least 4 chars long and contain one number').isLength({
        min: 4
      }).equals(req.body.confirmPassword);

    var errors = req.validationErrors();
    if (errors) {
      req.session.errors = errors;
      req.session.success = false;
    } else {
      req.session.success = true;
      res.redirect('/');
    }
    console.log("Username = " + username + ",Email is" + email +
      ", password is " + password);
    console.log("Signup Successful");
    res.redirect('/login');
    //res.render('ledcontrol.html');
  });
router.get('/admin', function(req, res) {
  session = req.session;
  if (session.uniqueId != 'admin') {
    res.send(
      'Unauthorized access  <a href = "/">Back to login page</a>');
    res.redirect('/logout');
  }
  console.log('Logged in As Admin');
  res.redirect('/ledcontrol');
});


router.get('/ledcontrol', function(req, res) {
  session = req.session;
  if (session.uniqueId != 'admin') {
    res.send(
      'Unauthorized access  <a href = "/">Back to Home page</a>');
    res.redirect('/logout');
  }
  console.log('Logged in As Admin to Ledcontrol');
  res.render('Ledcontrol', {
    layout: 'layouts/LedcontrolLayout.hbs',
    title: 'Ledcontrol',
    success: req.session.success,
    errors: req.session.errors
  });
});

//App route for publishing RGB data
router.post('/user/rgbdata', function(req, res) {
  console.log(req.body); // your JSON
  res.send(req.body); // echo the result back
  console.log("form submitted");

});

//for API call
router.get('/api', function(req, res) {
  //res.send('Welcome to my API');
  var url =
    'http://samples.openweathermap.org/data/2.5/forecast?id=524901&appid=b1b15e88fa797225412429c1c50c122a1';
  request.get(url, (error, response, body) => {
    let json = JSON.parse(body);
    console.log("Got a response: ", json);
    res.end(JSON.stringify(url));
    /* http.get(url, function(res){
        var body = '';

        res.on('data', function(chunk){
            body += chunk;
        });

        res.on('end', function(){
            var APIRes = JSON.parse(body);
            console.log("Got a response: ", APIRes.json);
        });
    }).on('error', function(e){
          console.log("Got an error: ", e);
    }); */
  });
});
// Logout endpoint
router.get('/logout', function(req, res) {
  req.session.destroy(function(error) {
    //call back
    console.log(error);
    res.redirect('/');

  })

});
//Redirect function
router.get('/redirect', function(req, res) {
  session = req.session;
  if (session.uniqueId == 'admin') {
    console.log(session.uniqueId);
    res.redirect('/admin');
  } else {
    res.send('Hey ' + req.session.uniqueId + ' You are not Authorized');
    res.redirect('/logout');
  }
});



module.exports = router;
