// server.js
var app = require('./app');
var rest = require('./rest');
var https = require('https');
var http = require('http');

var port = normalizePort(process.env.PORT || '3000');
app.set('port', port);
var options = {
  dotfiles: 'ignore',
  etag: false,
  extensions: ['htm', 'html'],
  index: false,
  maxAge: '1d',
  redirect: false,
  setHeaders: function(res, path, stat) {
    res.set('x-timestamp', Date.now())
  }
}
var httpserver = http.createServer(app).listen(80);
var server = https.createServer(options, app).listen(443);
app.listen = function() {
  var server = http.createServer(this);
  return server.listen.apply(server, arguments);
};
// Listen for requests
server.listen(port);
server.on('error', onError);
server.on('listening', onListening);
//console.log('Running server at Port ' + port);
